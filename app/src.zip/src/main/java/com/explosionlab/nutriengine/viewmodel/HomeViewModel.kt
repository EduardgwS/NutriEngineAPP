package com.explosionlab.nutriengine.viewmodel

import android.app.Application
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.explosionlab.nutriengine.model.Mensagem
import com.explosionlab.nutriengine.repository.AuthRepository
import com.explosionlab.nutriengine.repository.ChatRepository
import com.explosionlab.nutriengine.repository.ConsumoRepository
import com.explosionlab.nutriengine.repository.HealthRepository
import com.explosionlab.nutriengine.repository.PerfilRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val authRepository = AuthRepository(application)
    private val chatRepository = ChatRepository(authRepository)
    private val healthRepo = HealthRepository(application)
    private val perfilRepo = PerfilRepository(application)
    private val consumoRepo = ConsumoRepository(application)

    // ── Estado observável pela MegumiScreen ─────────────────────────────────────

    private val _mensagens = MutableStateFlow<List<Mensagem>>(emptyList())
    val mensagens: StateFlow<List<Mensagem>> = _mensagens.asStateFlow()

    var carregando by mutableStateOf(false); private set

    val nomeUsuario: String get() = authRepository.carregarNome()

    // ── Estado de calorias para a HomeScreen ────────────────────────────────────

    private val _caloriasHoje = MutableStateFlow(0.0)
    val caloriasHoje: StateFlow<Double> = _caloriasHoje.asStateFlow()

    private val _caloriasRecomendadas = MutableStateFlow(0)
    val caloriasRecomendadas: StateFlow<Int> = _caloriasRecomendadas.asStateFlow()

    init {
        carregarHistorico()
        carregarCaloriasHome()
        observarMudancas()
    }


    // ── Calorias do dia atual ──────────────────────────────────────────────────

    fun recarregarCaloriasHome() = carregarCaloriasHome()

    private fun carregarCaloriasHome() {
        viewModelScope.launch {
            try {
                val hoje = LocalDate.now()
                var kcalParaExibir = 0.0

                if (healthRepo.isDisponivel() && healthRepo.temPermissoes()) {
                    // 1. Tenta ler do Health Connect (Igual você fez no Relatório)
                    val nutricaoHC = healthRepo.lerNutricaoHoje()

                    if (nutricaoHC.calorias > 0) {
                        kcalParaExibir = nutricaoHC.calorias

                        // 2. Sincroniza com o local para garantir que o fallback funcione depois
                        consumoRepo.salvarConsumoLocal(
                            data = hoje.toString(),
                            kcal = nutricaoHC.calorias,
                            proteinaG = nutricaoHC.proteinas,
                            carboG = nutricaoHC.carboidratos,
                            gorduraG = nutricaoHC.gorduras
                        )
                    }
                }

                // 3. Se o Health Connect falhou ou retornou zero, usa o fallback local
                if (kcalParaExibir <= 0) {
                    val local = consumoRepo.carregarConsumoLocal(hoje.toString())
                    kcalParaExibir = local.kcal
                }

                // 4. Busca o perfil para as calorias recomendadas
                val perfil = perfilRepo.carregarPerfil(
                    nomeGoogleFallback = authRepository.carregarNome()
                )

                // 5. Atualiza os estados da UI
                _caloriasHoje.value = kcalParaExibir
                _caloriasRecomendadas.value = perfil.caloriasRecomendadas

            } catch (e: Exception) {
                android.util.Log.e("HomeViewModel", "Erro ao carregar dados: ${e.message}")
            }
        }
    }

    // ── Histórico ─────────────────────────────────────────────────────────────

    fun recarregar() = carregarHistorico()

    private fun carregarHistorico() {
        viewModelScope.launch {
            carregando = true
            try {
                val historico = chatRepository.carregarHistorico(limite = 50)
                _mensagens.value = historico
            } finally {
                carregando = false
            }
        }
    }

    // ── Enviar mensagem ────────────────────────────────────────────────────────

    fun enviarMensagem(texto: String, imagemBytes: ByteArray? = null) {
        val textoLimpo = texto.trim()
        if (textoLimpo.isEmpty() && imagemBytes == null) return
        if (carregando) return

        _mensagens.value = _mensagens.value + Mensagem(textoLimpo, ehUsuario = true)
        carregando = true

        viewModelScope.launch {
            val historicoJson = montarHistoricoSaudeJson()
            val resposta = chatRepository.enviarMensagem(textoLimpo, imagemBytes, historicoJson)
            _mensagens.value = _mensagens.value + Mensagem(resposta, ehUsuario = false)
            carregando = false
        }
    }

    // ── Monta JSON de saúde dos últimos 7 dias ─────────────────────────────────

    private suspend fun montarHistoricoSaudeJson(): String {
        return try {
            val perfil =
                perfilRepo.carregarPerfil(nomeGoogleFallback = authRepository.carregarNome())

            // Perfil do usuário
            val perfilJson = JSONObject().apply {
                if (perfil.peso > 0) put("peso_kg", perfil.peso)
                if (perfil.altura > 0) put("altura_m", perfil.altura)
                if (perfil.idade > 0) put("idade", perfil.idade)
                put("objetivo", perfil.objetivo.label)
                put("nivel_atividade", perfil.nivelAtividade.label)
                put("sexo", perfil.sexo.label)
                if (perfil.caloriasRecomendadas > 0)
                    put("kcal_recomendadas", perfil.caloriasRecomendadas)
            }

            // Histórico nutricional: HC se disponível, fallback nas SharedPreferences
            val hcDisponivel = healthRepo.isDisponivel() && healthRepo.temPermissoes()
            val hoje = LocalDate.now()

            val historicoArray = JSONArray()
            for (diasAtras in 6 downTo 0) {
                val data = hoje.minusDays(diasAtras.toLong())

                val (kcal, prot, carbo, gord) = if (hcDisponivel) {
                    val n = healthRepo.lerNutricaoDia(data)
                    listOf(n.calorias, n.proteinas, n.carboidratos, n.gorduras)
                } else {
                    val local = consumoRepo.carregarConsumoLocal(data.toString())
                    listOf(local.kcal, local.proteinaG, local.carboG, local.gorduraG)
                }

                // Só inclui dias com algum dado registrado
                if (kcal > 0 || prot > 0 || carbo > 0 || gord > 0) {
                    historicoArray.put(JSONObject().apply {
                        put("data", data.toString())
                        put("kcal", kcal.toInt())
                        put("proteinas_g", String.format("%.1f", prot).toDouble())
                        put("carboidratos_g", String.format("%.1f", carbo).toDouble())
                        put("gorduras_g", String.format("%.1f", gord).toDouble())
                    })
                }
            }

            JSONObject().apply {
                put("perfil", perfilJson)
                put("historico_nutricional", historicoArray)
            }.toString()

        } catch (e: Exception) {
            android.util.Log.w("HomeViewModel", "Falha ao montar histórico de saúde: ${e.message}")
            ""
        }

    }

    private fun observarMudancas() {
        viewModelScope.launch {
            // Coleta o "alarme" do repository
            consumoRepo.mudancas.collect {
                Log.d("HomeViewModel", "Mudança detectada no Repository! Atualizando UI...")
                carregarCaloriasHome()
            }
        }
    }
}