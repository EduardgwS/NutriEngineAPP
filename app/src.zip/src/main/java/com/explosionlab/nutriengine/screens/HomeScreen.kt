package com.explosionlab.nutriengine.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.explosionlab.nutriengine.viewmodel.HomeViewModel
import kotlin.math.min

@Composable
fun HomeScreen(
    innerPadding: PaddingValues = PaddingValues(),
    viewModel: HomeViewModel,
) {

    val caloriasHoje         by viewModel.caloriasHoje.collectAsStateWithLifecycle()
    val caloriasRecomendadas by viewModel.caloriasRecomendadas.collectAsStateWithLifecycle()

    // Recarrega sempre que a tela volta ao primeiro plano (ON_RESUME),
    // capturando adições feitas em outras abas (ex: Pesquisar).
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.recarregarCaloriasHome()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.Top,
    ) {
        CaloriasProgressBar(
            caloriasHoje         = caloriasHoje,
            caloriasRecomendadas = caloriasRecomendadas,
        )
    }
}

// ── Componente: barra de progresso de calorias ─────────────────────────────

@Composable
private fun CaloriasProgressBar(
    caloriasHoje: Double,
    caloriasRecomendadas: Int,
) {
    val progresso = if (caloriasRecomendadas > 0)
        min(1f, (caloriasHoje / caloriasRecomendadas).toFloat())
    else 0f

    val progressoAnimado by animateFloatAsState(
        targetValue   = progresso,
        animationSpec = tween(durationMillis = 800),
        label         = "caloriasProgresso",
    )

    val corBarra = when {
        progresso >= 1f   -> MaterialTheme.colorScheme.error
        progresso >= 0.8f -> Color(0xFFF59E0B)
        else              -> MaterialTheme.colorScheme.primary
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically,
        ) {
            Text(
                text       = "Calorias de hoje",
                style      = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text       = "${(progresso * 100).toInt()}%",
                style      = MaterialTheme.typography.labelLarge,
                color      = corBarra,
                fontWeight = FontWeight.Bold,
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(18.dp)
                .clip(RoundedCornerShape(50))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(progressoAnimado)
                    .clip(RoundedCornerShape(50))
                    .background(corBarra),
            )
        }

        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text  = "${caloriasHoje.toInt()} kcal ingeridas",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text  = "Meta: $caloriasRecomendadas kcal",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}