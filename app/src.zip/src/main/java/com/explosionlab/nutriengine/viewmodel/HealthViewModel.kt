package com.explosionlab.nutriengine.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.explosionlab.nutriengine.repository.AuthRepository
import com.explosionlab.nutriengine.repository.ConsumoRepository
import com.explosionlab.nutriengine.repository.HealthRepository
import kotlinx.coroutines.launch
import java.time.LocalDate

data class HealthUiState(
    // Corpo
    val peso:             Double? = null,
    val altura:           Double? = null,
    // Atividade
    val caloriasAtivas:   Double  = 0.0,
    // Nutrição do dia
    val nutricao:         HealthRepository.NutricaoDiaria = HealthRepository.NutricaoDiaria(),
    // UI
    val isCarregando:     Boolean = false,
    val mensagemErro:     String  = "",
    val mensagemOk:       String  = "",
    val temPermissoes:    Boolean = false,
    val hcDisponivel:     Boolean = false,
)

class HealthViewModel(application: Application) : AndroidViewModel(application) {

    private val healthRepo  = HealthRepository(application)
    private val authRepo    = AuthRepository(application)
    private val consumoRepo = ConsumoRepository(application)

    var state by mutableStateOf(HealthUiState()); private set

    init {
        state = state.copy(hcDisponivel = healthRepo.isDisponivel())
    }

    // ── Permissões ─────────────────────────────────────────────────────────────

    fun verificarPermissoes() {
        viewModelScope.launch {
            state = state.copy(temPermissoes = healthRepo.temPermissoes())
        }
    }

    // ── Leitura ────────────────────────────────────────────────────────────────

    fun carregarDados() {
        viewModelScope.launch {
            state = state.copy(isCarregando = true, mensagemErro = "", mensagemOk = "")

            val nutricaoHC = healthRepo.lerNutricaoHoje()

            // Sempre que o HC devolver dados (inclusive lidos por outros apps),
            // atualiza o cache local para manter as SharedPreferences em sincronia.
            if (nutricaoHC.calorias > 0 || nutricaoHC.proteinas > 0
                || nutricaoHC.carboidratos > 0 || nutricaoHC.gorduras > 0) {

                val hoje = java.time.LocalDate.now().toString()
                consumoRepo.salvarConsumoLocal(
                    data      = hoje,
                    kcal      = nutricaoHC.calorias,
                    proteinaG = nutricaoHC.proteinas,
                    carboG    = nutricaoHC.carboidratos,
                    gorduraG  = nutricaoHC.gorduras,
                )
            }

            state = state.copy(
                peso           = healthRepo.lerUltimoPeso(),
                altura         = healthRepo.lerUltimaAltura(),
                caloriasAtivas = healthRepo.lerCaloriasAtivasHoje(),
                nutricao       = nutricaoHC,
                isCarregando   = false,
            )
        }
    }

    // ── Escrita — Peso ────────────────────────────────────────────────────────

    fun salvarPeso(input: String) {
        val kg = input.toDoubleOrNull()
        if (kg == null || kg <= 0) {
            state = state.copy(mensagemErro = "Peso inválido. Ex: 72.5")
            return
        }
        viewModelScope.launch {
            state = state.copy(isCarregando = true, mensagemErro = "", mensagemOk = "")

            // Health Connect
            val ok = healthRepo.salvarPeso(kg)

            state = state.copy(
                isCarregando = false,
                mensagemOk   = if (ok) "Peso salvo!" else "",
                mensagemErro = if (!ok) "Falha ao salvar peso." else "",
            )
            if (ok) carregarDados()
        }
    }

    // ── Escrita — Altura ──────────────────────────────────────────────────────

    fun salvarAltura(input: String) {
        val metros = input.toDoubleOrNull()
        if (metros == null || metros <= 0) {
            state = state.copy(mensagemErro = "Altura inválida. Ex: 1.75")
            return
        }
        viewModelScope.launch {
            state = state.copy(isCarregando = true, mensagemErro = "", mensagemOk = "")

            // Health Connect
            val ok = healthRepo.salvarAltura(metros)

            state = state.copy(
                isCarregando = false,
                mensagemOk   = if (ok) "Altura salva!" else "",
                mensagemErro = if (!ok) "Falha ao salvar altura." else "",
            )
            if (ok) carregarDados()
        }
    }

    // ── Escrita — Nutrição ─────────────────────────────────────────────────────

    fun salvarNutricao(entrada: HealthRepository.EntradaNutricao) {
        val temAlgo = listOf(
            entrada.carboidratos, entrada.proteinas, entrada.gorduras, entrada.calorias,
            entrada.vitaminaC, entrada.vitaminaD, entrada.vitaminaA, entrada.vitaminaB12,
            entrada.calcio, entrada.ferro, entrada.sodio, entrada.potassio
        ).any { it != null }

        if (!temAlgo) {
            state = state.copy(mensagemErro = "Preencha pelo menos um campo nutricional.")
            return
        }

        viewModelScope.launch {
            state = state.copy(isCarregando = true, mensagemErro = "", mensagemOk = "")

            // Health Connect
            val ok = healthRepo.salvarNutricao(entrada)

            if (ok) {
                // Lê o total acumulado do dia no HC (inclui o registro recém-salvo)
                val totalHoje = healthRepo.lerNutricaoHoje()
                val hoje      = LocalDate.now().toString()

                // Persiste localmente como fallback offline
                consumoRepo.salvarConsumoLocal(
                    data      = hoje,
                    kcal      = totalHoje.calorias,
                    proteinaG = totalHoje.proteinas,
                    carboG    = totalHoje.carboidratos,
                    gorduraG  = totalHoje.gorduras,
                )
            }

            state = state.copy(
                isCarregando = false,
                mensagemOk   = if (ok) "Nutrição registrada!" else "",
                mensagemErro = if (!ok) "Falha ao salvar nutrição." else "",
            )
            if (ok) carregarDados()
        }
    }
}