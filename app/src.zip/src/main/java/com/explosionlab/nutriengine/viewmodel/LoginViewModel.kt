package com.explosionlab.nutriengine.viewmodel

import android.app.Activity
import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.explosionlab.nutriengine.repository.AuthRepository
import kotlinx.coroutines.launch

class LoginViewModel(application: Application) : AndroidViewModel(application) {

    // AuthRepository recebe o Application context — seguro, não vaza memória
    private val authRepository = AuthRepository(application)

    // ── Estado observável pela LoginScreen ────────────────────────────────────
    var isLoading  by mutableStateOf(false)  ; private set
    var errorMsg   by mutableStateOf("")     ; private set

    /**
     * Inicia o fluxo de login Google.
     * Recebe a Activity porque o Credential Manager precisa dela
     * para exibir o seletor de contas — não há como evitar.
     * O ViewModel não guarda referência à Activity (só a usa durante a chamada).
     */
    fun fazerLogin(activity: Activity, onSucesso: () -> Unit) {
        viewModelScope.launch {
            isLoading = true
            errorMsg  = ""

            val resultado = authRepository.fazerLoginGoogle(activity)

            if (resultado.sucesso) {
                onSucesso()
            } else {
                errorMsg = resultado.mensagem
            }

            isLoading = false
        }
    }
}