package com.explosionlab.nutriengine.model

import java.util.UUID

/**
 * Representa uma mensagem no chat da Megumi.
 * [id] gerado automaticamente — usado como key no LazyColumn para evitar
 * recomposições desnecessárias quando a lista cresce.
 */
data class Mensagem(
    val texto:     String,
    val ehUsuario: Boolean,
    val id:        String = UUID.randomUUID().toString()
)

/** Resultado de uma tentativa de login. */
data class ResultadoLogin(
    val sucesso:  Boolean,
    val nome:     String = "",
    val mensagem: String = ""
)
