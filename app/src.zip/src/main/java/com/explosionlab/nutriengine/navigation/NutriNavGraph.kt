package com.explosionlab.nutriengine.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.explosionlab.nutriengine.screens.*
import com.explosionlab.nutriengine.viewmodel.AppViewModel
import com.explosionlab.nutriengine.viewmodel.HomeViewModel

/**
 * Grafo de navegação completo do app.
 *
 * Extraído da MainActivity para mantê-la enxuta.
 * Recebe [appViewModel] para tela inicial e ações de auth,
 * e [homeViewModel] que é compartilhado entre PesquisarScreen e MegumiScreen.
 */
@Composable
fun NutriNavGraph(
    appViewModel:  AppViewModel,
    homeViewModel: HomeViewModel,
) {
    val navController = rememberNavController()

    val rotasComNav = remember { NutriTab.entries.map { it.rota }.toSet() }

    val rotaAtual = navController
        .currentBackStackEntryFlow
        .collectAsState(initial = navController.currentBackStackEntry)
        .value?.destination?.route

    val mostrarNav = rotaAtual in rotasComNav
    val tabAtual   = NutriTab.entries.find { it.rota == rotaAtual } ?: NutriTab.INICIO

    // Criado uma única vez — lambdas capturam navController estável
    val itensMenu = remember {
        listOf(
            MenuItemData(
                label = "Health Connect",
                icone = Icons.Default.HealthAndSafety,
                acao  = { navController.navigate("health") }
            ),
            MenuItemData(
                label = "Sair",
                icone = Icons.AutoMirrored.Filled.ExitToApp,
                acao  = {
                    appViewModel.logout()
                    navController.navigate("login") {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        )
    }

    Scaffold(
        topBar = {
            if (mostrarNav) {
                TopBar(
                    itensMenu      = itensMenu
                )
            }
        },
        bottomBar = {
            if (mostrarNav) {
                BottomBar(
                    tabAtual      = tabAtual,
                    onTabSelected = { tab ->
                        navController.navigate(tab.rota) {
                            popUpTo(NutriTab.INICIO.rota) { saveState = true }
                            launchSingleTop = true
                            restoreState    = true
                        }
                    }
                )
            }
        }
    ) { innerPadding ->

        NavHost(
            navController    = navController,
            startDestination = appViewModel.telaInicial
        ) {

            // ── Sem nav ──────────────────────────────────────────────────────
            composable("login") {
                LoginScreen(
                    onLoginSucesso = {
                        if (appViewModel.perfilCompleto()) {
                            navController.navigate(NutriTab.INICIO.rota) {
                                popUpTo("login") { inclusive = true }
                            }
                        } else {
                            navController.navigate("hc_intro") {
                                popUpTo("login") { inclusive = true }
                            }
                        }
                    }
                )
            }

            // ── Intro do Health Connect (onboarding, passo 1) ────────────────
            composable("hc_intro") {
                HealthConnectIntroScreen(
                    onContinuar = {
                        navController.navigate("perfil") {
                            popUpTo("hc_intro") { inclusive = true }
                        }
                    }
                )
            }

            // ── Perfil (onboarding, passo 2) ─────────────────────────────────
            composable("perfil") {
                ConhecerPerfilScreen(
                    onConcluido = {
                        navController.navigate(NutriTab.INICIO.rota) {
                            popUpTo("perfil") { inclusive = true }
                        }
                    }
                )
            }

            // ── Abas principais ───────────────────────────────────────────────
            composable(NutriTab.INICIO.rota) {
                HomeScreen(innerPadding = innerPadding, viewModel = homeViewModel)
            }

            composable(NutriTab.PESQUISAR.rota) {
                PesquisarScreen(
                    innerPadding = innerPadding
                )
            }

            composable(NutriTab.MEGUMI.rota) {
                MegumiScreen(
                    innerPadding = innerPadding,
                    viewModel    = homeViewModel
                )
            }

            composable(NutriTab.RELATORIO.rota) {
                RelatorioScreen(innerPadding = innerPadding)
            }

            // ── Telas secundárias ─────────────────────────────────────────────
            composable("health") {
                HealthScreen(onVoltar = { navController.popBackStack() })
            }
        }
    }
}