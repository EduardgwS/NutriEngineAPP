package com.explosionlab.nutriengine.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.explosionlab.nutriengine.repository.AuthRepository
import com.explosionlab.nutriengine.repository.PerfilRepository
import com.explosionlab.nutriengine.screens.NutriTab

/**
 * ViewModel de escopo de aplicação.
 *
 * Centraliza as dependências de autenticação e perfil que antes ficavam
 * criadas com remember {} dentro da composição da MainActivity.
 * Também expõe [telaInicial] calculado uma única vez e [logout] reutilizável.
 */
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val authRepo   = AuthRepository(application)
    private val perfilRepo = PerfilRepository(application)

    /** Rota de entrada calculada uma única vez ao iniciar o app. */
    val telaInicial: String = when {
        !authRepo.estaLogado()       -> "login"
        !perfilRepo.perfilCompleto() -> "hc_intro"
        else                         -> NutriTab.INICIO.rota
    }

    fun perfilCompleto(): Boolean = perfilRepo.perfilCompleto()

    /** Limpa o token JWT local e retorna para o fluxo de login. */
    fun logout() {
        authRepo.limparToken()
    }
}
