package com.explosionlab.nutriengine

import okhttp3.OkHttpClient

/**
 * Singleton do OkHttpClient — reutiliza pool de conexões e cache em toda a app.
 * Nunca crie instâncias avulsas de OkHttpClient; use sempre este objeto.
 */
object NetworkModule {
    val httpClient: OkHttpClient by lazy { OkHttpClient() }
}
